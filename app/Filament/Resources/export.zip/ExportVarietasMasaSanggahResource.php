<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportVarietasMasaSanggahResource\Pages;
use App\Filament\Resources\ExportVarietasMasaSanggahResource\RelationManagers;
use App\Models\ExportVarietasMasaSanggah;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Database\Eloquent\Model;

class ExportVarietasMasaSanggahResource extends Resource
{
    protected static ?string $model = ExportVarietasMasaSanggah::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 19;
    protected static ?string $navigationLabel = 'Export Database Varietas Tersanggah';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('pemohon.nama_produsen')
                ->label("Nama Pemohon"),
                Tables\Columns\TextColumn::make('komoditas.nama')
                ->label("Nama Komoditas"),
                Tables\Columns\TextColumn::make('kelkomoditas.nama_kelompok')
                ->label("Kelompok Komoditas"),
                Tables\Columns\TextColumn::make('nama_varietas')
                ->label("Nama Varietas"),
                Tables\Columns\TextColumn::make('tanggal_entri')
                ->label("Tanggal Entri")
                    ->date(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportVarietasMasaSanggahs::route('/'),
            'create' => Pages\CreateExportVarietasMasaSanggah::route('/create'),
            'edit' => Pages\EditExportVarietasMasaSanggah::route('/{record}/edit'),
        ];
    }    
}
