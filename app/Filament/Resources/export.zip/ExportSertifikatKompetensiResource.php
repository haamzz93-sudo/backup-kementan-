<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportSertifikatKompetensiResource\Pages;
use App\Filament\Resources\ExportSertifikatKompetensiResource\RelationManagers;
use App\Models\ExportSertifikatKompetensi;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Database\Eloquent\Model;

class ExportSertifikatKompetensiResource extends Resource
{
    protected static ?string $model = ExportSertifikatKompetensi::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 16;
    protected static ?string $navigationLabel = 'Export Database Sertifikat Kompetensi';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('lembaga_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('no_serti')
                    ->maxLength(255),
                Forms\Components\Textarea::make('status')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('komkel_id'),
                Forms\Components\Textarea::make('komoditas_id')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('varietas_id')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('jenis_kompetensi'),
                Forms\Components\Textarea::make('luas_lahan')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('upload')
                    ->maxLength(16777215),
                Forms\Components\DatePicker::make('tgl_awal'),
                Forms\Components\DatePicker::make('tgl_akhir'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('produsenbenih.nama_lembaga')
                ->label("Nama Lembaga"),
                Tables\Columns\TextColumn::make('no_serti')
                ->label("No. Sertifikat"),
                Tables\Columns\TextColumn::make('kelkomoditas.nama_kelompok')
                ->label("Kelompok Komoditas"),
                Tables\Columns\TextColumn::make('komoditas.nama')
                ->label("Nama Komoditas"),
                Tables\Columns\TextColumn::make('varietas.nama_varietas')
                ->label("Nama Varietas"),
                Tables\Columns\TextColumn::make('jenis_kompetensi')
                ->label("Jenis Kompetensi"),
                Tables\Columns\TextColumn::make('luas_lahan')
                ->label("Luas Lahan"),
                Tables\Columns\TextColumn::make('tgl_awal')
                ->label("Berlaku Sertifikat")
                    ->date(),
                Tables\Columns\TextColumn::make('tgl_akhir')
                ->label("Berlaku s/d")
                    ->date(),
                    
                Tables\Columns\TextColumn::make('status')
                ->enum([
                    '1' => 'Berlaku',
                    '2' => 'Kadaluarsa',
                ])
                ->label("Status"),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportSertifikatKompetensis::route('/'),
            'create' => Pages\CreateExportSertifikatKompetensi::route('/create'),
            'edit' => Pages\EditExportSertifikatKompetensi::route('/{record}/edit'),
        ];
    }    
}
