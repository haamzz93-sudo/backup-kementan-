<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportProduksiStokResource\Pages;
use App\Filament\Resources\ExportProduksiStokResource\RelationManagers;
use App\Models\ExportProduksiStok;
use App\Models\Komoditas;
use App\Models\LaporanBenihPTM;
use App\Models\LaporanLabelMati;
use App\Models\LaporanProduksiMati;
use App\Models\PemeriksaanTanaman;
use App\Models\PenerimaanBatangBawah;
use App\Models\PenyaluranStokBenih;
use App\Models\ProdusenBenih;
use App\Models\ProsesPerbanyakanBenih;
use App\Models\Varietas;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Tables\Filters\Filter;

class ExportProduksiStokResource extends Resource
{
    protected static ?string $model = ExportProduksiStok::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 14;
    protected static ?string $navigationLabel = 'Export Database Produksi dan Stok';
    // protected static bool $shouldRegisterNavigation = false;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('lembaga.nama_lembaga')
                ->label("Nama Lembaga")
                ->searchable()
                            ->sortable(),
                Tables\Columns\TextColumn::make('kelkomoditas.nama_kelompok')
                ->label("Kelompok Komoditas")
                ->searchable()
                ->sortable(),
                Tables\Columns\TextColumn::make('komoditas.nama')
                ->label("Komoditas")
                ->searchable()
                ->sortable(),
                Tables\Columns\TextColumn::make('varietas.nama_varietas')
                ->label("Varietas")
                ->searchable()
                ->sortable(),
                Tables\Columns\TextColumn::make('cara.cara_banyak')->searchable()
                ->sortable(),
                Tables\Columns\TextColumn::make('golongan.gol_banyak')->searchable()
                ->sortable(),
                Tables\Columns\TextColumn::make('jum_target')
                ->getStateUsing(function($record) {
                    $tes3 = $record->jum_target;
                    $tes = $record->satuan->nama_satuan;
                     return $tes3." ".$tes;
                 })->searchable()
                 ->sortable(),
                 //perbanyakan start//
                    Tables\Columns\TextColumn::make('tanam')
                    ->label("Berhasil Perbanyakan")
                ->getStateUsing(function($record) {
                    $tanam = ProsesPerbanyakanBenih::where('target_benih_id',$record->id)->first();
                    if($tanam>="0"){
                        return $tanam->pengadaan_benih;;
                    }else{
                        return "null";  
                    }
                 })->searchable()
                 ->sortable(),
                 Tables\Columns\TextColumn::make('tamanmati')
                 ->label("Gagal Perbanyakan")
             ->getStateUsing(function($record) {
                    $tmati = LaporanProduksiMati::where('target_benih_id',$record->id)->first();
                 if($tmati>="0"){
                     return $tmati->produksi_mati;
                 }else{
                     return "0";  
                 }
              })->searchable()
              ->sortable(),
                 //perbanyakan end//
                 //ptm start//
                Tables\Columns\TextColumn::make('ptm')
                    ->label("Berhasil PTM")
                    ->getStateUsing(function($record) {
                        $ptm = LaporanBenihPTM::where('target_benih_id',$record->id)->first();
                            if($ptm>="0"){
                                return $ptm->jum_panen;
                            }else{
                                return "0";
                            }
                        })->searchable()
                        ->sortable(),
                Tables\Columns\TextColumn::make('ptmmati')
                    ->label("Gagal PTM")
                    ->getStateUsing(function($record) {
                        $ptmmati = LaporanLabelMati::where('target_benih_id',$record->id)->first();
                            if($ptmmati>="0"){
                                return $ptmmati->produksi_mati;
                            }else{
                                return "0";
                            }
                        })->searchable()
                        ->sortable(),
                 //ptm end//

                 //label start//
                 Tables\Columns\TextColumn::make('label1')
                 ->label("Berlabel")
                 ->getStateUsing(function($record) {
                    $ptm = LaporanBenihPTM::where('target_benih_id',$record->id)->first();
                    $label1 = PemeriksaanTanaman::where('lap_benih_panen_id',$ptm->id)->first();
                        if($label1>="0"){
                            return $label1->jumlah_lanjut;
                        }else{
                            return "0";
                        }
                    })->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('label2')
                 ->label("Belum Berlabel")
                 ->getStateUsing(function($record) {
                    $ptm = LaporanBenihPTM::where('target_benih_id',$record->id)->first();
                    $label2 = PemeriksaanTanaman::where('lap_benih_panen_id',$ptm->id)->first();
                        if($label2>="0"){
                            return $label2->jumlah_tunda;
                        }else{
                            return "0";
                        }
                    })->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('label3')
                 ->label("Gagal Berlabel")
                 ->getStateUsing(function($record) {
                    $ptm = LaporanBenihPTM::where('target_benih_id',$record->id)->first();
                    $label3 = PemeriksaanTanaman::where('lap_benih_panen_id',$ptm->id)->first();
                        if($label3>="0"){
                            return $label3->jumlah_gagal;
                        }else{
                            return "0";
                        }
                    })->searchable()
                    ->sortable(),
                 //label end//
                 //penyaluran start//
                 Tables\Columns\TextColumn::make('salur')
                 ->label("Tersalur")
                 ->getStateUsing(function($record) {
                    $salur = PenyaluranStokBenih::where('target_benih_id',$record->id)->first();
                        if($salur>="0"){
                            return $salur->jumlah;
                        }else{
                            return "0";
                        }
                    })->searchable()
                    ->sortable(),
                 Tables\Columns\TextColumn::make('stok')
                 ->label("Sisa Stok")
                 ->getStateUsing( function ($record){
                     $jb = $record->jum_s_benih;
                     $ja = $record->jum_s_ada;
                     $js = $record->jum_s_salur;
                     $jm = $record->jum_s_mati;
                     
                     return ($jb+$ja)-($js+$jm);
                 })->searchable()
                 ->sortable(),
                 //penyaluran end//
            ])
            ->filters([
                Filter::make('lembaga.nama_lembaga')
                ->label('Nama Lembaga'),
                Filter::make('komoditas.nama')
                ->label('Komoditas'),
                Filter::make('varietas.nama_varietas')
                ->label('Varietas'),
            ])
            ->actions([
                //Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                //Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportProduksiStoks::route('/'),
            'create' => Pages\CreateExportProduksiStok::route('/create'),
            'edit' => Pages\EditExportProduksiStok::route('/{record}/edit'),
        ];
    }    
}
