<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportPohonIndukResource\Pages;
use App\Filament\Resources\ExportPohonIndukResource\RelationManagers;
use App\Models\ExportPohonInduk;

use App\Models\PohonInduk;
use App\Models\Komoditas;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ExportPohonIndukResource extends Resource
{
    protected static ?string $model = ExportPohonInduk::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 13;
    protected static ?string $navigationLabel = 'Export Database Tanaman Induk';
    //protected static bool $shouldRegisterNavigation = false;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('pohon_induk_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('pemilik_pohon_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('lembaga_serti_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('lembaga_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('no_registrasi')
                    ->maxLength(255),
                Forms\Components\TextInput::make('jumlah_pohon')
                    ->maxLength(255),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('no_registrasi')->searchable(),
                Tables\Columns\TextColumn::make('pohoninduk.tahun_tanam')->label('Tahun Tanam')->searchable(),
                Tables\Columns\TextColumn::make('pohoninduk.tahun_regis')->label('Tahun Registrasi')->searchable(),
                Tables\Columns\TextColumn::make('pohoninduk.komoditas.nama')->label('Komoditas')->searchable(),
                Tables\Columns\TextColumn::make('pohoninduk.varietas.nama_varietas')->label('Varietas')->searchable(),
                Tables\Columns\TextColumn::make('pohoninduk.label_induk')->label('Kelas Benih'),
                Tables\Columns\TextColumn::make('pohoninduk.kelasbenih.kelas_benih')->label('Status Tanaman Induk'),
                Tables\Columns\TextColumn::make('pemilikpohon.nama_lembaga')->label('Pemilik')->searchable(),
                Tables\Columns\TextColumn::make('lembagasertifikasi.nama_lembaga')->label('Lembaga Sertifikasi'),
                Tables\Columns\TextColumn::make('kondisipohon.kapasitas')->label('Taksiran Sumber Perbanyakan'),
                
                ])
            ->filters([
                //
            ])
            ->actions([
                //Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                //Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportPohonInduks::route('/'),
            'create' => Pages\CreateExportPohonInduk::route('/create'),
            'edit' => Pages\EditExportPohonInduk::route('/{record}/edit'),
        ];
    }    
}
