<?php

namespace App\Filament\Resources;

use App\Filament\Resources\VarietasResource\Pages;
use App\Filament\Resources\VarietasResource\RelationManagers;
use App\Models\Varietas;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class VarietasResource extends Resource
{
    protected static ?string $model = Varietas::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 18;
    protected static ?string $navigationLabel = 'Export Database Varietas Terdaftar';

    protected static bool $shouldRegisterNavigation = true;
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('komkel_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('komoditas_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('nama_varietas')
                    ->maxLength(255),
                Forms\Components\Textarea::make('kode')
                    ->maxLength(65535),
                Forms\Components\TextInput::make('produsen_id')
                    ->maxLength(255),
                Forms\Components\Textarea::make('no_sk')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('tahun_daftar')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('upload_produk')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('upload_penciri')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('upload_deskripsi')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('no_reg')
                    ->maxLength(16777215),
                Forms\Components\Textarea::make('wil_adaptasi'),
                Forms\Components\Textarea::make('iklim'),
                Forms\Components\Textarea::make('asal')
                    ->maxLength(16777215),
                Forms\Components\TextInput::make('varietas_sanggah_id')
                    ->maxLength(255),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('kelkomoditas.nama_kelompok')
                ->searchable(),
                Tables\Columns\TextColumn::make('komoditas.nama'),
                Tables\Columns\TextColumn::make('nama_varietas'),
                Tables\Columns\TextColumn::make('kode'),
                Tables\Columns\TextColumn::make('pemohon.nama_produsen'),
                Tables\Columns\TextColumn::make('no_sk'),
                Tables\Columns\TextColumn::make('tahun_daftar'),
                Tables\Columns\TextColumn::make('upload_produk'),
                Tables\Columns\TextColumn::make('upload_penciri'),
                Tables\Columns\TextColumn::make('upload_deskripsi'),
                Tables\Columns\TextColumn::make('no_reg'),
                Tables\Columns\TextColumn::make('wil_adaptasi')
                ->getStateUsing(function ($record){
                    $tes = $record->wil_adaptasi;
                    if ($tes){
                        foreach($tes as $data){
                            if($data == "1"){
                                $dd[] = "Dataran Rendah";
                            }elseif($data == "2"){
                                $dd[] = "Dataran Menengah";
                            }elseif($data == "3"){
                                $dd[] = "Dataran Tinggi";
                            }
                               
                        }
                        return $dd;
                    }else{
                        return "null";
                    }  
                }),
                Tables\Columns\TextColumn::make('iklim')
                ->getStateUsing(function ($record){
                    $iklim = $record->iklim;
                    if ($iklim){
                        foreach($iklim as $ik){
                            if($ik == "1"){
                               $k[] = "Musim Hujan";
                            }elseif($ik == "2"){
                                $k[] = "Musim Kemarau";
                            }
                        }
                        return $k;
                    }else{
                        return "null";
                    }  
                }),
                Tables\Columns\TextColumn::make('asal')
                ->enum([
                    '1' => 'Introduksi',
                    '2' => 'Dalam Negeri',
                ])
            ])
            ->filters([
                //
            ])
            ->actions([
                //Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                //Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListVarietas::route('/'),
            'create' => Pages\CreateVarietas::route('/create'),
            'edit' => Pages\EditVarietas::route('/{record}/edit'),
        ];
    }    
}
