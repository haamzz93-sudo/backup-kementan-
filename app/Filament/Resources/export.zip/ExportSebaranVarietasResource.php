<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportSebaranVarietasResource\Pages;
use App\Filament\Resources\ExportSebaranVarietasResource\RelationManagers;
use App\Models\ExportSebaranVarietas;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ExportSebaranVarietasResource extends Resource
{
    protected static ?string $model = ExportSebaranVarietas::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 17;
    protected static ?string $navigationLabel = 'Export Database Sebaran Varietas';
    //protected static bool $shouldRegisterNavigation = false;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('lembaga_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('provinces_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('regencies_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('komkel_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('komoditas_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('varietas_id')
                    ->maxLength(255),
                Forms\Components\DatePicker::make('tanggal_lapor_sebar'),
                Forms\Components\Textarea::make('luas_sebar')
                    ->maxLength(65535),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('provinces.name'),
                Tables\Columns\TextColumn::make('regencies.name'),
                Tables\Columns\TextColumn::make('kelkomoditas.nama_kelompok'),
                Tables\Columns\TextColumn::make('komoditas.nama'),
                Tables\Columns\TextColumn::make('varietas.nama_varietas'),
                Tables\Columns\TextColumn::make('luas_sebar')
                ->getStateUsing(function($record) {
                    $tes3 = $record->luas_sebar;
                     return $tes3." ha";
                 }),
            ])
            ->filters([
                //
            ])
            ->actions([
                //Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                //Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportSebaranVarietas::route('/'),
            'create' => Pages\CreateExportSebaranVarietas::route('/create'),
            'edit' => Pages\EditExportSebaranVarietas::route('/{record}/edit'),
        ];
    }    
}
