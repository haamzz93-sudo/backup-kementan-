<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExportProduksiNonAPBNResource\Pages;
use App\Filament\Resources\ExportProduksiNonAPBNResource\RelationManagers;
use App\Models\ExportProduksiNonAPBN;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Database\Eloquent\Model;

class ExportProduksiNonAPBNResource extends Resource
{
    protected static ?string $model = ExportProduksiNonAPBN::class;

    protected static ?string $navigationIcon = 'heroicon-o-database';
    protected static ?string $navigationGroup = 'Export';
    protected static ?int $navigationSort = 15;
    protected static ?string $navigationLabel = 'Export Database Produksi Non APBN';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('produksiumum.nama_lembaga')
                ->label("Nama Lembaga"),
                Tables\Columns\TextColumn::make('komoditas.nama')
                ->label("Nama Komoditas"),
                Tables\Columns\TextColumn::make('varietas.nama_varietas')
                ->label("Nama Varietas"),
                Tables\Columns\TextColumn::make('satuan.nama_satuan')
                ->label("Satuan"),
                Tables\Columns\TextColumn::make('sumber_dana')
                ->label("Sumber Dana"),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    public static function canEdit(Model $record): bool
    {
        return false;
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListExportProduksiNonAPBNS::route('/'),
            'create' => Pages\CreateExportProduksiNonAPBN::route('/create'),
            'edit' => Pages\EditExportProduksiNonAPBN::route('/{record}/edit'),
        ];
    }    
}
