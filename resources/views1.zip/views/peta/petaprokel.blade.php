<style>
    #map { height: 500px; }
</style>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>

     <div id="map"></div>   
      
     <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
    integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
    crossorigin=""></script>
    <link rel="stylesheet" href="//unpkg.com/leaflet-gesture-handling/dist/leaflet-gesture-handling.min.css" type="text/css">
    <script src="//unpkg.com/leaflet-gesture-handling"></script>
<script>
    var map = L.map('map',
    {
      'center': [0.948926, 118.0148634],
      'zoom': 4,
      'zoomControl': true,
      'gestureHandling': true,
      'zoomControl': false,
    }
    );
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);
$.getJSON('{{ asset("json/provinsi.json")}} ',
function (geojson) {
                  L.geoJson(geojson, {
                    onEachFeature: function (feature, layer) {
                          @foreach($provinsis as $prov)
                         @php 
                         if($getkomoditas){
                             if($getjenis){
                             $target_benih1map = DB::table('target_benih')
                                        ->select(
                                            'jum_target',
                                     DB::RAW("(select sum(a.jum_panen) from lap_benih_panen a where a.target_benih_id = target_benih.id) as jum_panen1"),
                                     DB::RAW("(select (sum(a.jumlah_gagal)) from lap_benih_label a join lap_benih_panen b on b.id=a.lap_benih_panen_id where b.target_benih_id = target_benih.id) as matiptm"),
                                     DB::RAW("(select sum(a.jumlah) from lap_pengurangan_stok a where a.target_benih_id = target_benih.id) as matilabel")
                                     )
                            		->join('lembaga','lembaga.id','target_benih.lembaga_id')
                            		->where('lembaga.provinces_id',$prov->id)
                            		->where([['target_benih.status','=',"active"],['target_benih.komoditas_id',$getkomoditas]])
                            		->where('lembaga.jenis_produsen_id',$getjenis)
                            		->where( 'target_benih.tahun', '=', $year  )
                            		->get(); 
                             }else{
                                 $target_benih1map = DB::table('target_benih')
                                 ->select(
                                     'jum_target',
                                     DB::RAW("(select sum(a.jum_panen) from lap_benih_panen a where a.target_benih_id = target_benih.id) as jum_panen1"),
                                     DB::RAW("(select (sum(a.jumlah_gagal)) from lap_benih_label a join lap_benih_panen b on b.id=a.lap_benih_panen_id where b.target_benih_id = target_benih.id) as matiptm"),
                                     DB::RAW("(select sum(a.jumlah) from lap_pengurangan_stok a where a.target_benih_id = target_benih.id) as matilabel")
                                     )
                            		->join('lembaga','lembaga.id','target_benih.lembaga_id')
                            		->where('lembaga.provinces_id',$prov->id)
                            		->where([['target_benih.status',"active"],['target_benih.komoditas_id',$getkomoditas]])
                            		->where( 'target_benih.tahun', '=', $year  )
                            		->get(); 
                             }
                         }else{
                             if($getjenis){
                             $target_benih1map = DB::table('target_benih')
                             ->select(
                                 'jum_target',
                                     DB::RAW("(select sum(a.jum_panen) from lap_benih_panen a where a.target_benih_id = target_benih.id) as jum_panen1"),
                                     DB::RAW("(select (sum(a.jumlah_gagal)) from lap_benih_label a join lap_benih_panen b on b.id=a.lap_benih_panen_id where b.target_benih_id = target_benih.id) as matiptm"),
                                     DB::RAW("(select sum(a.jumlah) from lap_pengurangan_stok a where a.target_benih_id = target_benih.id) as matilabel")
                                     )
                            		->join('lembaga','lembaga.id','target_benih.lembaga_id')
                            		->where('lembaga.provinces_id',$prov->id)
                            		->where('lembaga.jenis_produsen_id',$getjenis)
                            		->where( 'target_benih.tahun', '=', $year  )
                            		->where('target_benih.status',"active")
                            		->get(); 
                             }else{
                                 $target_benih1map = DB::table('target_benih')
                                 ->select(
                                     'jum_target',
                                     DB::RAW("(select sum(a.jum_panen) from lap_benih_panen a where a.target_benih_id = target_benih.id) as jum_panen1"),
                                     DB::RAW("(select (sum(a.jumlah_gagal)) from lap_benih_label a join lap_benih_panen b on b.id=a.lap_benih_panen_id where b.target_benih_id = target_benih.id) as matiptm"),
                                     DB::RAW("(select sum(a.jumlah) from lap_pengurangan_stok a where a.target_benih_id = target_benih.id) as matilabel")
                                     )
                            		->join('lembaga','lembaga.id','target_benih.lembaga_id')
                            		->where('lembaga.provinces_id',$prov->id)
                            		->where( 'target_benih.tahun', '=', $year  )
                            		->where('target_benih.status',"active")
                            		->get(); 
                             }
                         }
                        $tare=$target_benih1map->sum('jum_target');
                        $real=$target_benih1map->sum('jum_panen1')-$target_benih1map->sum('matiptm')-$target_benih1map->sum('matilabel');
                        if($tare>0){
                        $tur = number_format($real*100/$tare, 2, ',', ' ');
                        }else{
                        $tur=0;
                        }
                        
                        @endphp
                          if(layer.feature.properties.ID == '{{ $prov->id}}')
                          {
                            layer.bindPopup(
                            '<b>PROVINSI {{$prov->name}}</b><br>JUMLAH PRODUSEN :</br>\
                            <table>\
                           @foreach($jenis_produsen as $jen)\
                            <tr>\
                                <td>{{$jen->nama_jenis}}</td>\
                                <td>:{{count($lembaga->where("provinces_id", $prov->id)->whereIn("jenis_produsen_id",$jen->id))}}</td>\
                            <tr>\
                           @endforeach\
                           @if($tare)\
                            <tr>\
                                <td colspan=3><b>KINERJA PROD. PTM TAHUN {{$year}} : {{$tur}} %</b></td>\
                            <tr>\
                            <tr>\
                                <td colspan=3><a href="#prov{{$prov->id}}"><button>Benih Siap Salur Provinsi Tahun {{$year}}</button></a></td>\
                            <tr>\
                            @endif\
                           <table>'

                            );
                            layer.setStyle({
                                @if($tare>0 and $real>0)
                                @if($tur==0)
                                  fillColor :'#FFFFFF',
                                @elseif($tur>0 and $tur<25)
                                fillColor :'#c7ff7d',
                                @elseif($tur>=25 and $tur<75)
                                fillColor :'#a5ff2e',
                                @elseif($tur>=75 and $tur<100)
                                fillColor :'#80e000',
                                @elseif($tur>=100)
                                fillColor :'#579900',
                                @endif
                                @elseif($tare>0 and $real==0)
                                fillColor :'#FFA500',
                                @endif
                                 weight: 0.5,
                                  opacity: 0.5,
                                  color: 'grey',  //Outline color
                                  fillOpacity: 3
                                  }) ;
                                  }
                                  @endforeach
                                                              }})
                                                              .addTo(map);
                                                              });
</script>