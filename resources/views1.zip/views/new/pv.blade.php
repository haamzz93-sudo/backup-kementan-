@extends('layout/pv')
@section('title')
	HOMEPAGE PROSEED
@endsection
@section('meta')
	<meta charset="utf-8" />
	<meta name="keywords" 				   content="Homepage PROSEED">
	<meta property="og:url"                content="" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="HOMEPAGE PROSEED" />
	<meta property="og:description"        content="" />
	<meta property="og:image"              content="" />
	<meta name="csrf-token" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
@endsection

@section('content')
    <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url('{{ asset('frontend/images/page-banner-1.jpg') }}')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>Penyebaran Varietas</h2>   
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
    <!--====== ABOUT PART START ======-->
    
    <section id="about-page" class="pt-70 pb-110">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
            @include('peta.petapv')
                </div> <!-- about cont -->
            </div> <!-- about items -->
        </div> <!-- container -->
    </section>
    
    <!--====== ABOUT PART ENDS ======-->

    <!--====== COUNTER PART START ======-->
    
    <div id="counter-part" class="bg_cover pt-65 pb-110" data-overlay="8" style="background-image: url('{{ asset('frontend/images/bg-2.jpg') }}')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="singel-counter text-center mt-40">
                        <span>Peta Sebaran Varietas Hortikultura</span>
                        <p>Per Provinsi</p>
                    </div> <!-- singel counter -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    
    <!--====== COUNTER PART ENDS ======-->
   
    <!--====== TEACHERS PART START ======-->
    
    <section id="teachers-part" class="pt-65 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title mt-50 pb-35">
                        <h3>Tabel Pendaftaran Varietas</h3>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="section-title mt-50 pb-35">
                        <h5>Terdaftar</h5>
                    </div> <!-- section title -->
                </div>
                <div class="col-lg-12 col-sm-12">
                    <div class="section-title mt-50 pb-35">
                        <h5>Masa Sanggah</h5>
                    </div> <!-- section title -->
                </div>
                <div class="col-lg-12 col-sm-12">
                <div class="section-title mt-50 pb-35">
                        <h5>Belum SK</h5>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== TEACHERS PART ENDS ======-->
   
    <!--====== BACK TO TOP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
    
    <!--====== BACK TO TOP PART ENDS ======-->
@endsection