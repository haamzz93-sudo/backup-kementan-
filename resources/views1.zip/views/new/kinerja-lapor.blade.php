@extends('layout/database')
@section('title')
HOMEPAGE PROSEED
@endsection
@section('meta')
<meta charset="utf-8" />
<meta name="keywords" content="Homepage PROSEED">
<meta property="og:url" content="" />
<meta property="og:type" content="article" />
<meta property="og:title" content="HOMEPAGE PROSEED" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta name="csrf-token" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
@endsection

@section('content')
<!--====== PAGE BANNER PART START ======-->

<section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url('{{ asset('frontend/images/page-banner-1.jpg') }}')">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-banner-cont">
                    <h2>Kinerja Pelaporan</h2>
                </div> <!-- page banner cont -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== PAGE BANNER PART ENDS ======-->

<!--====== ABOUT PART START ======-->

<section id="about-page" class="pt-70 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="">
                    <div class="shop-top-search" style="background-color:#387905;margin:10px">
                        <div class="shop-bar">
                            <p style="color:white">Filter Data :</p>
                        </div><!-- shop bar -->

                        <div class="shop-select">
                            <form method="GET" action="">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <select id="date-dropdown" name="year">
                                            @php
                                            $currentYear = date('Y');
                                            $startYear = 2023;

                                            for ($year = $currentYear; $year >= $startYear; $year--) {
                                            echo "<option value=\"$year\">$year</option>";
                                            }
                                            @endphp
                                        </select>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <button onclick="this.form.submit()">Proses</button>
                                    </div>
                                </div>
                            </form>

                        </div> <!-- shop select -->
                    </div> <!-- shop top search -->
                </form>
            </div>
            <div class="col-lg-12">
                <div class="table-container table-responsive table-striped">
                    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            @php
                            if(isset($_GET['year'])){
                            $year1 = $_GET['year'];
                            }else{
                            $year1 = date("Y");
                            }
                            @endphp
                            <tr>
                                <th>No.</th>
                                <th>Nama Pengguna</th>
                                <td>Lembaga</td>
                                <td>Provinsi</td>
                                <td>Alamat</td>
                                <td>Wewenang</td>
                                @foreach($month as $m)
                                <th>{{$m[1]}} {{$year1}}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($user->whereNotNull('lembaga_id') as $us)

                            <tr>
                                <td>{{$no++}}</td>
                                <td>{{$us->name}}</td>
                                <td>
                                    @if(isset($us->produsenbenih->nama_lembaga))
                                    {{$us->produsenbenih->nama_lembaga}}
                                    @else
                                    User Tidak Memiliki Lembaga
                                    @endif
                                </td>
                                <td>@if(isset($us->produsenbenih->nama_lembaga))
                                    {{$us->produsenbenih->provinces->name}}
                                    @else
                                    User Tidak Memiliki Lembaga
                                    @endif
                                </td>
                                <td>@if(isset($us->produsenbenih->nama_lembaga))
                                    {{$us->produsenbenih->alamat}}
                                    @else
                                    User Tidak Memiliki Lembaga
                                    @endif
                                </td>
                                @php
                                $roles = $us->roles;
                                $roleName = $roles[0]->name;
                                @endphp
                                <td>
                                    {{$roleName}}
                                </td>
                                @foreach($month as $m)
                                @php
                                $monthyear = $m[0];
                                $log = DB::table('activity_log')
                                ->select(
                                'activity_log.causer_id as idnya',
                                DB::raw('DATE_FORMAT(activity_log.created_at,"%m-%Y") as bulan_tahun')
                                )
                                ->where('activity_log.causer_id',$us->id)
                                ->where( DB::raw('DATE_FORMAT(activity_log.created_at,"%m-%Y")'),$monthyear )
                                ->where( 'description','not like','%logged%' )
                                ->count('activity_log.causer_id');
                                @endphp
                                @if($log>0)
                                <td><a href="{{url('/')}}/detail-kinerja/{{$us->id}}/{{$monthyear}}">{{$log}}</a></td>
                                @else
                                <td>{{$log}}</td>
                                @endif
                                @endforeach
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div style="">
                        {!! $user->withQueryString()->links() !!}
                    </div>
                </div>
            </div> <!-- about cont -->
        </div> <!-- about items -->
    </div> <!-- container -->
</section>

<!--====== ABOUT PART ENDS ======-->

<!--====== BACK TO TOP PART START ======-->

<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

<!--====== BACK TO TOP PART ENDS ======-->
@endsection