@extends('layout/database')
@section('title')
HOMEPAGE PROSEED
@endsection
@section('meta')
<meta charset="utf-8" />
<meta name="keywords" content="Homepage PROSEED">
<meta property="og:url" content="" />
<meta property="og:type" content="article" />
<meta property="og:title" content="HOMEPAGE PROSEED" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta name="csrf-token" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
@endsection

@section('content')
<!--====== PAGE BANNER PART START ======-->

<section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url('{{ asset('frontend/images/page-banner-1.jpg') }}')">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-banner-cont">
                    <h2>Pohon Induk</h2>
                </div> <!-- page banner cont -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== PAGE BANNER PART ENDS ======-->

<!--====== ABOUT PART START ======-->

<section id="about-page" class="pt-70 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="">
                    <div class="shop-top-search" style="background-color:#387905;margin:10px">
                        <div class="shop-bar">
                            <p style="color:white">Filter Data :</p>
                        </div><!-- shop bar -->

                        <div class="shop-select">


                        </div> <!-- shop select -->
                    </div> <!-- shop top search -->
                </form>
            </div>
            <div class="col-lg-12">
                <div class="table-container table-responsive table-striped">
                    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>No. Registrasi</th>
                                <th>Jenis Label</th>
                                <th>Nama Komoditas</th>
                                <th>Nama Varietas</th>
                                <th>Lembaga Sertifikasi</th>
                                <th>Titik Lokasi</th>
                                <th>Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($pohon as $poh)
                            <tr>
                                <td>{{$poh->no_registrasi}}</td>
                                <td>@if(isset($poh->pohoninduk->label_induk))
                                    {{$poh->pohoninduk->label_induk}} @else
                                    Jenis Label Belum Ada
                                    @endif
                                </td>
                                <td>@if(isset($poh->pohoninduk->komoditas->nama))
                                    {{$poh->pohoninduk->komoditas->nama}}
                                    @else
                                    Komoditas Belum Ada
                                    @endif
                                </td>
                                <td>@if(isset($poh->pohoninduk->varietas->nama_varietas))
                                    {{$poh->pohoninduk->varietas->nama_varietas}}
                                    @else
                                    Varietas Belum Ada
                                    @endif
                                </td>
                                <td>@if(isset($poh->pohoninduk->lemser->nama_lembaga))
                                    {{$poh->pohoninduk->lemser->nama_lembaga}}
                                    @else
                                    Lembaga Sertifikasi Belum Ada
                                    @endif
                                </td>
                                <td>
                                    @if(isset($poh->pohoninduk->latitude) and isset($poh->pohoninduk->longitude))
                                    <a href="https://maps.google.com/?q={{$poh->pohoninduk->latitude}},{{$poh->pohoninduk->longitude}}" target="_blank">Klik Disini</a>
                                </td>
                                @else
                                Belum ada lokasi
                                @endif
                                <td><a href={{url('/detail-pohon/'.$poh->id)}}>Detail</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div style="">
                        {!! $pohon->withQueryString()->links() !!}
                    </div>
                </div>
            </div> <!-- about cont -->
        </div> <!-- about items -->
    </div> <!-- container -->
</section>

<!--====== ABOUT PART ENDS ======-->

<!--====== BACK TO TOP PART START ======-->

<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

<!--====== BACK TO TOP PART ENDS ======-->
@endsection