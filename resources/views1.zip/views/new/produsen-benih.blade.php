@extends('layout/database')
@section('title')
HOMEPAGE PROSEED
@endsection
@section('meta')
<meta charset="utf-8" />
<meta name="keywords" content="Homepage PROSEED">
<meta property="og:url" content="" />
<meta property="og:type" content="article" />
<meta property="og:title" content="HOMEPAGE PROSEED" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta name="csrf-token" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
@endsection

@section('content')

<!--====== PAGE BANNER PART START ======-->

<section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url('{{ asset('frontend/images/page-banner-1.jpg') }}')">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-banner-cont">
                    <h2>Produsen Benih</h2>
                </div> <!-- page banner cont -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== PAGE BANNER PART ENDS ======-->

<!--====== ABOUT PART START ======-->

<section id="about-page" class="pt-70 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="">
                    <div class="shop-top-search" style="background-color:#387905;margin:10px">
                        <div class="shop-bar">
                            <p style="color:white">Filter Data :</p>
                        </div><!-- shop bar -->

                        <div class="shop-select">
                            <select name="jenis_produsen" id="jenis_produsen" onchange="this.form.submit()">
                                <option value="0">Semua</option>
                                @foreach($jenis_produsen as $jen)
                                @if(isset($jenprod))
                                @if($jenprod==$jen->id)
                                <option style="width:100%" value={{$jen->id}} selected="selected">{{$jen->nama_jenis}}</option>
                                @else
                                <option style="width:100%" value={{$jen->id}}>{{$jen->nama_jenis}}</option>
                                @endif
                                @else
                                <option style="width:100%" value={{$jen->id}}>{{$jen->nama_jenis}}</option>
                                @endif
                                @endforeach
                            </select>
                        </div> <!-- shop select -->
                    </div> <!-- shop top search -->
                </form>
            </div>

            <div class="col-lg-12">
                <div class="table-container table-responsive table-striped">
                    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>KODE PRODUSEN</th>
                                <th>NAMA PEMILIK/KEPALA</th>
                                <th>NAMA LEMBAGA</th>
                                <th>NAMA LEMBAGA SERTIFIKASI</th>
                                <th>DAERAH</th>
                                <th>JENIS PRODUSEN</th>
                                <th>JENIS KOMPETENSI</th>
                                <th>MEMILIKI SERTIFIKAT KOMPETENSI</th>
                                <th>DETAIL</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($lembaga as $lem)
                            <tr>
                                <td>{{$lem->kode_produsen}}</td>
                                <td>{{$lem->nama_kepala}}</td>
                                <td>{{$lem->nama_lembaga}}</td>
                                <td>{{$lem->lembaga_serti_id}}</td>
                                <td>{{$lem->alamat}},
                                    @if($lem->villages_id)
                                    {{$lem->villages->name}}
                                    @else
                                    Desa Belum Dibuat
                                    @endif,
                                    @if($lem->districts_id)
                                    {{$lem->districts->name}}
                                    @else
                                    Kecamatan Belum Dibuat
                                    @endif,
                                    @if($lem->regencies_id)
                                    {{$lem->regencies->name}}
                                    @else
                                    Kab/Kota Belum Dibuat
                                    @endif,
                                    @if($lem->provinces_id)
                                    {{$lem->provinces->name}}
                                    @else
                                    Provinsi Belum Dibuat
                                    @endif
                                </td>
                                <td>{{$lem->jenis_produsen->nama_jenis}}</td>
                                @php
                                $idToValue = [
                                "produsen" => "Produsen",
                                "pengedar" => "Pengedar"
                                ];
                                $jsonArray1 = collect($lem->jenis_kompetensi);
                                $jsonArray = json_decode($jsonArray1);
                                if ($jsonArray !== null) {
                                foreach ($jsonArray as &$id) {
                                if (array_key_exists($id, $idToValue)) {
                                $id = $idToValue[$id];
                                }
                                }
                                }
                                $jsonResult = implode(", ", $jsonArray);
                                @endphp
                                <td>
                                    @if($jsonResult)
                                    {{$jsonResult}}
                                    @else
                                    Data Belum Terisi
                                    @endif
                                </td>
                                <td>
                                    {{$lem->sertifikatkompetensi->groupBy('no_serti')->count()}}
                                </td>
                                <td><a href={{url('/detail-produsen/'.$lem->id)}}>Detail</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div style="">
                        {!! $lembaga->withQueryString()->links() !!}
                    </div>

                </div>
            </div> <!-- about cont -->
        </div> <!-- about items -->
    </div> <!-- container -->
</section>

<!--====== ABOUT PART ENDS ======-->

<!--====== BACK TO TOP PART START ======-->

<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

<!--====== BACK TO TOP PART ENDS ======-->
@endsection