@extends('layout/database')
@section('title')
	HOMEPAGE PROSEED
@endsection
@section('meta')
	<meta charset="utf-8" />
	<meta name="keywords" 				   content="Homepage PROSEED">
	<meta property="og:url"                content="" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="HOMEPAGE PROSEED" />
	<meta property="og:description"        content="" />
	<meta property="og:image"              content="" />
	<meta name="csrf-token" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
@endsection

@section('content')
    <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url('{{ asset('frontend/images/page-banner-1.jpg') }}')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>Varietas Masa Sanggah</h2>   
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
    <!--====== ABOUT PART START ======-->
    
    <section id="about-page" class="pt-70 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="">
                    <div class="shop-top-search" style="background-color:#387905;margin:10px">
                        <div class="shop-bar">
                            <p style="color:white">Filter Data :</p>
                        </div><!-- shop bar -->

                        <div class="shop-select">


                        </div> <!-- shop select -->
                    </div> <!-- shop top search -->
                </form>
            </div>
            <div class="col-lg-12">
                <div class="table-container table-responsive table-striped">
                    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Tanggal Pendaftaran</th>
                                <th>Kelompok Komoditas</th>
                                <th>Kode Komoditas</th>
                                <th>Nama Komoditas</th>
                                <th>Nama Varietas</th>
                                <th>Nama Pemohon</th>                               
                                <th>Pemulia</th>
                                <th>Peneliti</th>
                                <th>Dokumen Deskripsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($varsan as $var)
                            <tr>
                                <td>{{$var->tanggal_entri}}</td>
                                <td>{{$var->kelkomoditas->nama_kelompok}}</td>
                                <td>{{$var->komoditas->kdkom}}</td>
                                <td>{{$var->komoditas->nama}}</td>
                                <td>{{$var->nama_varietas}}</td>
                                <td>{{$var->pemohon->nama_produsen}}
                                </td>
                                <td>{{$var->pemulia}}</td>
                                <td>{{$var->peneliti}}</td>
                                <td><a href="{{$var->upload_deskripsi}}" target="_blank">Klik Disini</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div style="">
                        {!! $varsan->withQueryString()->links() !!}
                    </div>
                </div>
            </div> <!-- about cont -->
        </div> <!-- about items -->
    </div> <!-- container -->
</section>
    
    <!--====== ABOUT PART ENDS ======-->

    <!--====== BACK TO TOP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
    
    <!--====== BACK TO TOP PART ENDS ======-->
@endsection